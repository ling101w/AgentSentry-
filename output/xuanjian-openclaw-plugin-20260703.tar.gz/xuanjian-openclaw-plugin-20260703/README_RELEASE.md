# 玄鉴 OpenClaw 插件交付包

版本日期：2026-07-03

作品名称：

> 玄鉴：面向智能体工具调用链的实时行为监督与风险拦截系统

## 包内容

| 路径 | 内容 |
|---|---|
| `openclaw-plugin/` | 可部署 OpenClaw 插件，包含源码、`dist/` 构建产物、8765 前端页面和安装脚本。 |
| `reports/` | 答辩报告、系统功能说明、算法说明、benchmark 结果和验收证据。 |
| `scripts/` | benchmark 复跑、完整验收和 OpenClaw UI 检查脚本。 |
| `cases/` | 中文安全案例集。 |
| `policies/` | 离线原型策略配置。 |
| `PROJECT_STRUCTURE.md` | 项目结构和分层说明。 |

第三方 benchmark 原始仓库体积较大，未打入交付包。当前可执行映射样例和真实结果已包含在：

```text
reports/benchmark_risk_tiered/
```

## 部署插件

在已安装 OpenClaw CLI 的环境中：

```bash
cd openclaw-plugin
npm run build
./setup.sh --force
```

启动或重启 OpenClaw Gateway 后访问：

```text
http://127.0.0.1:8765/
http://127.0.0.1:8765/command-lab
http://127.0.0.1:8765/security-screen
```

## 验证

```bash
npm --prefix openclaw-plugin run test:policy
python3 scripts/run_full_acceptance_tests.py
```

## 文档阅读顺序

先看：

```text
reports/START_HERE.md
```

再看：

```text
reports/competition_report.md
reports/system_functionality.md
reports/technical_design_and_algorithms.md
reports/project_name_and_benchmark_summary.md
```
